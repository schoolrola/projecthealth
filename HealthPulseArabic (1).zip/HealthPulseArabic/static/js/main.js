document.addEventListener('DOMContentLoaded', function() {
    // Handle search functionality
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            let found = false;

            // Search through all content sections
            const contentSections = document.querySelectorAll('.content-section');
            contentSections.forEach(section => {
                const text = section.textContent.toLowerCase();
                if (text.includes(searchTerm)) {
                    section.style.display = 'block';
                    found = true;
                    // Highlight matching text
                    highlightText(section, searchTerm);
                } else {
                    section.style.display = 'none';
                    // Remove highlights if no match
                    removeHighlights(section);
                }
            });

            // Search through cards on the main page
            const cards = document.querySelectorAll('.card');
            cards.forEach(card => {
                const text = card.textContent.toLowerCase();
                if (text.includes(searchTerm)) {
                    card.style.display = 'block';
                    found = true;
                    // Highlight matching text
                    highlightText(card, searchTerm);
                } else {
                    card.style.display = 'none';
                    // Remove highlights if no match
                    removeHighlights(card);
                }
            });

            // Show/hide no results message
            const searchContainer = searchInput.closest('.search-container');
            let noResultsMsg = searchContainer.querySelector('.no-results-message');

            if (!found && searchTerm !== '') {
                if (!noResultsMsg) {
                    noResultsMsg = document.createElement('div');
                    noResultsMsg.className = 'no-results-message alert alert-info mt-2';
                    searchContainer.appendChild(noResultsMsg);
                }
                noResultsMsg.textContent = 'لا توجد نتائج للبحث';
                noResultsMsg.style.display = 'block';
            } else if (noResultsMsg) {
                noResultsMsg.style.display = 'none';
            }
        });
    }

    // Function to highlight matching text
    function highlightText(element, searchTerm) {
        const walker = document.createTreeWalker(
            element,
            NodeFilter.SHOW_TEXT,
            null,
            false
        );

        let node;
        while (node = walker.nextNode()) {
            const text = node.textContent.toLowerCase();
            if (text.includes(searchTerm)) {
                const span = document.createElement('span');
                span.className = 'search-highlight';
                const regex = new RegExp(searchTerm, 'gi');
                span.innerHTML = node.textContent.replace(regex, match => `<mark>${match}</mark>`);
                node.parentNode.replaceChild(span, node);
            }
        }
    }

    // Function to remove highlights
    function removeHighlights(element) {
        const highlights = element.querySelectorAll('.search-highlight');
        highlights.forEach(highlight => {
            const parent = highlight.parentNode;
            parent.replaceChild(document.createTextNode(highlight.textContent), highlight);
        });
    }

    // Handle quiz functionality
    window.checkAnswers = function() {
        const correctAnswers = {
            'q1': '2',
            'q2': '2',
            'q3': '1'
        };

        let score = 0;
        let total = Object.keys(correctAnswers).length;

        for (let question in correctAnswers) {
            const selectedAnswer = document.querySelector(`input[name="${question}"]:checked`);
            if (selectedAnswer && selectedAnswer.value === correctAnswers[question]) {
                score++;
            }
        }

        const resultsDiv = document.getElementById('quiz-results');
        const percentage = (score / total) * 100;
        let message = `<div class="alert alert-info">نتيجتك: ${score} من ${total} (${percentage}%)<br>`;

        if (percentage === 100) {
            message += 'ممتاز! لديك معرفة جيدة بالمعلومات الصحية.';
        } else if (percentage >= 70) {
            message += 'جيد! يمكنك تحسين معرفتك أكثر بقراءة المزيد.';
        } else {
            message += 'نشجعك على قراءة المزيد من المعلومات الصحية في موقعنا.';
        }
        message += '</div>';

        resultsDiv.innerHTML = message;
    };

    // Handle contact form validation
    const contactForm = document.querySelector('form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            if (!this.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            this.classList.add('was-validated');
        });
    }
});